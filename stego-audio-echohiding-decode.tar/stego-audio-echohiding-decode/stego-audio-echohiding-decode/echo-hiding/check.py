import sys
import numpy as np
from scipy.io import wavfile

def check_audio_properties(file_path):
    sample_rate, audio_data = wavfile.read(file_path)

    print(f"Tần số mẫu (Sample Rate): {sample_rate} Hz")

    num_channels = audio_data.shape[1] if len(audio_data.shape) > 1 else 1
    duration = len(audio_data) / sample_rate  
    print(f"Số kênh (Channels): {num_channels}")
    print(f"Độ dài (Duration): {duration:.2f} seconds")

    bit_depth = audio_data.itemsize * 8  
    print(f"Bit Depth: {bit_depth} bits")

    max_amplitude = np.max(np.abs(audio_data))
    print(f"Độ lớn tối đa (Max Amplitude): {max_amplitude}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Cách dùng: python check.py <ten_file.wav>")
        sys.exit(1)
    
    file_path = sys.argv[1]
    check_audio_properties(file_path)

