import numpy as np
import scipy.io.wavfile as wavfile
import sys

def calculate_echo_energy(audio_with_echo, original_audio, delay, hop_size):
    
    audio_with_echo = audio_with_echo.astype(float)
    original_audio = original_audio.astype(float)
    num_frames = min(140, len(audio_with_echo) // hop_size)  
    echo_energies = []
    
    for i in range(num_frames):
        start = i * hop_size
        end = start + hop_size
        
        if end > len(audio_with_echo):
            break
            
        frame_with_echo = audio_with_echo[start:end]
        frame_original = original_audio[start:end]
        
       
        echo_energy = 0
        for j in range(len(frame_with_echo) - delay):
            echo_diff = abs(frame_with_echo[j + delay] - frame_original[j + delay])
            echo_energy += echo_diff  
        
        echo_energies.append(echo_energy)
    
    return echo_energies

def main():
   
    if len(sys.argv) != 4:
        print("Sử dụng: python script.py <file_with_echo> <file_original> <output_file>")
        sys.exit(1)

    file_with_echo = sys.argv[1]  
    file_original = sys.argv[2]  
    output_file = sys.argv[3]     

    sample_rate, audio_with_echo = wavfile.read(file_with_echo)
    _, original_audio = wavfile.read(file_original)

    if len(audio_with_echo.shape) > 1:
        audio_with_echo = np.mean(audio_with_echo, axis=1).astype(np.int16)
    if len(original_audio.shape) > 1:
        original_audio = np.mean(original_audio, axis=1).astype(np.int16)
 
    delay = 100     
    hop_size = 1024  
    
    # Tính năng lượng echo
    echo_energies = calculate_echo_energy(audio_with_echo, original_audio, delay, hop_size)
    
    # Lưu năng lượng echo vào file
    with open(output_file, 'w', encoding='utf-8') as f:
        for i, energy in enumerate(echo_energies):
            f.write(f"Khung {i}: {energy:.2f}\n")
    
    # In kết quả để kiểm tra
    print("Năng lượng echo của 140 khung đầu tiên:")
    for i, energy in enumerate(echo_energies):
        print(f"Khung {i}: {energy:.2f}")
    print(f"Kết quả đã được lưu vào {output_file}")

if __name__ == "__main__":
    main()
