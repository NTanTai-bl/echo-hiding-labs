import numpy as np
import scipy.io.wavfile as wavfile
import sys

def bits_to_text(bits):
    
    text = ""
    for i in range(0, len(bits), 8):
        byte = bits[i:i+8]
        if len(byte) == 8:
            byte_str = ''.join(str(b) for b in byte)
            char_code = int(byte_str, 2)
            text += chr(char_code)
    return text

def extract_message(audio_with_echo, original_audio, delay, hop_size):

    audio_with_echo = audio_with_echo.astype(float)
    original_audio = original_audio.astype(float)
    num_frames = len(audio_with_echo) // hop_size
    extracted_bits = []
    
    for i in range(num_frames):
        start = i * hop_size
        end = start + hop_size
        
        if end > len(audio_with_echo):
            break
            
        frame_with_echo = audio_with_echo[start:end]
        frame_original = original_audio[start:end]
        
        # Tính năng lượng echo
        echo_energy = 0
        for j in range(len(frame_with_echo) - delay):
            echo_energy += abs(frame_with_echo[j + delay] - frame_original[j + delay])
        
        # Ngưỡng để xác định bit
        threshold = 1000
        bit = 1 if echo_energy > threshold else 0
        extracted_bits.append(bit)
    
    return extracted_bits

def main():
    # Kiểm tra số lượng tham số
    if len(sys.argv) != 4:
        print("Sử dụng: python script.py <file_with_echo> <file_original> <output_file>")
        sys.exit(1)
    
    # Lấy tham số từ câu lệnh
    file_with_echo = sys.argv[1]  # File âm thanh đã nhúng tin
    file_original = sys.argv[2]   # File âm thanh gốc
    output_file = sys.argv[3]     # File đầu ra để lưu chuỗi nhị phân

    # Đọc file âm thanh
    sample_rate, audio_with_echo = wavfile.read(file_with_echo)
    _, original_audio = wavfile.read(file_original)
    
    # Chuyển sang mono nếu là stereo
    if len(audio_with_echo.shape) > 1:
        audio_with_echo = np.mean(audio_with_echo, axis=1).astype(np.int16)
    if len(original_audio.shape) > 1:
        original_audio = np.mean(original_audio, axis=1).astype(np.int16)
    
    # Thông số
    delay = 100      # Độ trễ echo (samples)
    hop_size = 1024  # Kích thước khung
    
    # Tách tin
    extracted_bits = extract_message(audio_with_echo, original_audio, delay, hop_size)
    
    # Lưu chuỗi nhị phân vào file
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(' '.join(str(bit) for bit in extracted_bits))
    
    # In kết quả để kiểm tra
    extracted_text = bits_to_text(extracted_bits)
    print(f"Chuỗi nhị phân đã tách: {extracted_bits}")
    print(f"Chuỗi nhị phân đã được lưu vào {output_file}")

if __name__ == "__main__":
    main()
