import sys

def binary_to_text(binary_str):
    text = ""
    for i in range(0, len(binary_str), 8):
        byte = binary_str[i:i+8]  
        if len(byte) == 8:  
            char_code = int(byte, 2) 
            text += chr(char_code)  
    return text

def main():
    
    if len(sys.argv) != 3:
        print("Sử dụng: python script.py <input_file> <output_file>")
        sys.exit(1)
 
    input_file = sys.argv[1]  
    output_file = sys.argv[2] 

    with open(input_file, 'r', encoding='utf-8') as f:
        binary_data = f.read().strip()
  
    binary_str = ''.join(binary_data.split())  

    text = binary_to_text(binary_str)

    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(text)

    print(f"Văn bản đã chuyển đổi: {text}")
    print(f"Văn bản đã được lưu vào {output_file}")

if __name__ == "__main__":
    main()
